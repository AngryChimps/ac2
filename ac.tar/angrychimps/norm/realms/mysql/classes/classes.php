<?php
namespace Norm\mysql;

class Ad {
    const ACTIVE_STATUS = 1;
    const CLOSED_STATUS = 2;
    const PROHIBITED_STATUS = 3;


    /** @var int */
    public $id;

    /** @var string */
    public $key;

    /** @var string */
    public $locationKey;

    /** @var string */
    public $companyKey;

    /** @var int */
    public $categoryId;

    /** @var int */
    public $subcategoryId;

    /** @var string */
    public $title;

    /** @var string */
    public $description;

    /** @var int */
    public $minutesRequired;

    /** @var int */
    public $minutesBookingNotice;

    /** @var decimal */
    public $price;

    /** @var float */
    public $discount;

    /** @var int */
    public $status;

    /** @var DateTime */
    public $createdAt;

    /** @var DateTime */
    public $updatedAt;


    public function __construct() {
    }
}

class AdCollection extends \ArrayObject {
}

class Member {
    const ACTIVE_STATUS = 1;
    const DELETED_STATUS = 2;
    const LOCKED_STATUS = 3;
    const BANNED_STATUS = 4;
    const PARTIAL_REGISTRATION_STATUS = 5;

    const USER_ROLE = 1;
    const SUPPORT_ROLE = 2;
    const ADMIN_ROLE = 3;
    const SUPER_ADMIN_ROLE = 4;


    /** @var int */
    public $mysqlId;

    /** @var string */
    public $id;

    /** @var string */
    public $email;

    /** @var string */
    public $name;

    /** @var int */
    public $status;

    /** @var int */
    public $role;

    /** @var Date */
    public $lastActivityDate;

    /** @var DateTime */
    public $createdAt;

    /** @var DateTime */
    public $updatedAt;


    public function __construct() {
        $this->lastActivityDate = new \DateTime();
    }
}

class MemberCollection extends \ArrayObject {
}

class Company {
    const BASIC_PLAN = 1;
    const PREMIUM_PLAN = 2;

    const ACTIVE_STATUS = 1;
    const CLOSED_STATUS = 2;
    const PROHIBITED_STATUS = 3;


    /** @var int */
    public $id;

    /** @var string */
    public $key;

    /** @var string */
    public $name;

    /** @var string */
    public $description;

    /** @var string */
    public $address;

    /** @var int */
    public $plan;

    /** @var int */
    public $ratingCount;

    /** @var int */
    public $ratingTotal;

    /** @var float */
    public $ratingAvg;

    /** @var int */
    public $flagTotal;

    /** @var string[] */
    public $administerMemberIds;

    /** @var string[] */
    public $locationKeys;

    /** @var int */
    public $status;

    /** @var DateTime */
    public $createdAt;

    /** @var DateTime */
    public $updatedAt;


    public function __construct() {
        $this->administerMemberIds = [];
        $this->locationKeys = [];
    }
}

class CompanyCollection extends \ArrayObject {
}

class MemberProfile {

    /** @var int */
    public $mysqlId;

    /** @var string */
    public $id;

    /** @var string */
    public $fbId;

    /** @var string */
    public $fbAccessToken;

    /** @var string */
    public $fname;

    /** @var string */
    public $lname;

    /** @var string */
    public $gender;

    /** @var string */
    public $locale;

    /** @var int */
    public $timezone;

    /** @var DateTime */
    public $createdAt;

    /** @var DateTime */
    public $updatedAt;


    public function __construct() {
    }
}

class MemberProfileCollection extends \ArrayObject {
}

class Location {

    /** @var int */
    public $id;

    /** @var string */
    public $key;

    /** @var string */
    public $companyId;

    /** @var string */
    public $name;

    /** @var string */
    public $street1;

    /** @var string */
    public $street2;

    /** @var string */
    public $city;

    /** @var string */
    public $state;

    /** @var string */
    public $zip;

    /** @var string */
    public $phone;

    /** @var string */
    public $directions;

    /** @var float */
    public $lat;

    /** @var float */
    public $long;

    /** @var string[] */
    public $photos;

    /** @var AdFlag[] */
    public $flags;

    /** @var DateTime */
    public $createdAt;

    /** @var DateTime */
    public $updatedAt;


    public function __construct() {
        $this->photos = [];
        $this->flags = [];
    }
}

class LocationCollection extends \ArrayObject {
}

