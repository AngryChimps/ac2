<?php

namespace AC\NormBundle\cached\realms\mysql\services;

use AC\NormBundle\Services\NormService;
use AC\NormBundle\Services\DatastoreService;
use AC\NormBundle\Services\traits\MysqlTrait;
use AC\NormBundle\Services\traits\PdoTrait;

use Norm\mysql\Ad;
use Norm\mysql\Member;
use Norm\mysql\Company;
use Norm\mysql\MemberProfile;
use Norm\mysql\Location;

class NormMysqlBaseService extends NormService {
    use MysqlTrait;
    use PdoTrait;

    /**
     * @param $pks array|int|string|\DateTime The primary key/keys values
     * @return Ad
     * @throws \Exception
     */
    public function getAd($pks) {
        return $this->getObjectByPks('Norm\mysql\Ad', $pks);
    }

    /**
     * @param $pks array An array of primary keys
     * @return AdCollection
     * @throws \Exception
     */
    public function getAdCollection($pks) {
        return $this->getCollectionByPks('Norm\mysql\AdCollection', $pks);
    }

    /**
     * @param $where string The WHERE clause
     * @param $params array The parameter values array
     * @return Ad
     * @throws \Exception
     */
    public function getAdByWhere($where, $params = array()) {
        return $this->getObjectByWhere('Norm\mysql\Ad', $where, $params);
    }

    /**
     * @param $sql string The entire SQL clause
     * @param $params array The parameter values array
     * @return Ad
     * @throws \Exception
     */
    public function getAdBySql($sql, $params = array()) {
        return $this->getObjectBySql('Norm\mysql\Ad', $sql, $params);
    }

    /**
     * @param $where string The WHERE clause
     * @param $params array The parameter values array
     * @return AdCollection
     * @throws \Exception
     */
    public function getAdCollectionByWhere($where, $params = array()) {
        return $this->getCollectionByWhere('Norm\mysql\AdCollection', $where, $params);
    }

    /**
     * @param $sql string The entire SQL clause
     * @param $params array The parameter values array
     * @return AdCollection
     * @throws \Exception
     */
    public function getAdCollectionBySql($sql, $params = array()) {
        return $this->getObjectBySql('Norm\mysql\Ad', $sql, $params);
    }


    /**
     * @param $pks array|int|string|\DateTime The primary key/keys values
     * @return Member
     * @throws \Exception
     */
    public function getMember($pks) {
        return $this->getObjectByPks('Norm\mysql\Member', $pks);
    }

    /**
     * @param $pks array An array of primary keys
     * @return MemberCollection
     * @throws \Exception
     */
    public function getMemberCollection($pks) {
        return $this->getCollectionByPks('Norm\mysql\MemberCollection', $pks);
    }

    /**
     * @param $where string The WHERE clause
     * @param $params array The parameter values array
     * @return Member
     * @throws \Exception
     */
    public function getMemberByWhere($where, $params = array()) {
        return $this->getObjectByWhere('Norm\mysql\Member', $where, $params);
    }

    /**
     * @param $sql string The entire SQL clause
     * @param $params array The parameter values array
     * @return Member
     * @throws \Exception
     */
    public function getMemberBySql($sql, $params = array()) {
        return $this->getObjectBySql('Norm\mysql\Member', $sql, $params);
    }

    /**
     * @param $where string The WHERE clause
     * @param $params array The parameter values array
     * @return MemberCollection
     * @throws \Exception
     */
    public function getMemberCollectionByWhere($where, $params = array()) {
        return $this->getCollectionByWhere('Norm\mysql\MemberCollection', $where, $params);
    }

    /**
     * @param $sql string The entire SQL clause
     * @param $params array The parameter values array
     * @return MemberCollection
     * @throws \Exception
     */
    public function getMemberCollectionBySql($sql, $params = array()) {
        return $this->getObjectBySql('Norm\mysql\Member', $sql, $params);
    }


    /**
     * @param $pks array|int|string|\DateTime The primary key/keys values
     * @return Company
     * @throws \Exception
     */
    public function getCompany($pks) {
        return $this->getObjectByPks('Norm\mysql\Company', $pks);
    }

    /**
     * @param $pks array An array of primary keys
     * @return CompanyCollection
     * @throws \Exception
     */
    public function getCompanyCollection($pks) {
        return $this->getCollectionByPks('Norm\mysql\CompanyCollection', $pks);
    }

    /**
     * @param $where string The WHERE clause
     * @param $params array The parameter values array
     * @return Company
     * @throws \Exception
     */
    public function getCompanyByWhere($where, $params = array()) {
        return $this->getObjectByWhere('Norm\mysql\Company', $where, $params);
    }

    /**
     * @param $sql string The entire SQL clause
     * @param $params array The parameter values array
     * @return Company
     * @throws \Exception
     */
    public function getCompanyBySql($sql, $params = array()) {
        return $this->getObjectBySql('Norm\mysql\Company', $sql, $params);
    }

    /**
     * @param $where string The WHERE clause
     * @param $params array The parameter values array
     * @return CompanyCollection
     * @throws \Exception
     */
    public function getCompanyCollectionByWhere($where, $params = array()) {
        return $this->getCollectionByWhere('Norm\mysql\CompanyCollection', $where, $params);
    }

    /**
     * @param $sql string The entire SQL clause
     * @param $params array The parameter values array
     * @return CompanyCollection
     * @throws \Exception
     */
    public function getCompanyCollectionBySql($sql, $params = array()) {
        return $this->getObjectBySql('Norm\mysql\Company', $sql, $params);
    }


    /**
     * @param $pks array|int|string|\DateTime The primary key/keys values
     * @return MemberProfile
     * @throws \Exception
     */
    public function getMemberProfile($pks) {
        return $this->getObjectByPks('Norm\mysql\MemberProfile', $pks);
    }

    /**
     * @param $pks array An array of primary keys
     * @return MemberProfileCollection
     * @throws \Exception
     */
    public function getMemberProfileCollection($pks) {
        return $this->getCollectionByPks('Norm\mysql\MemberProfileCollection', $pks);
    }

    /**
     * @param $where string The WHERE clause
     * @param $params array The parameter values array
     * @return MemberProfile
     * @throws \Exception
     */
    public function getMemberProfileByWhere($where, $params = array()) {
        return $this->getObjectByWhere('Norm\mysql\MemberProfile', $where, $params);
    }

    /**
     * @param $sql string The entire SQL clause
     * @param $params array The parameter values array
     * @return MemberProfile
     * @throws \Exception
     */
    public function getMemberProfileBySql($sql, $params = array()) {
        return $this->getObjectBySql('Norm\mysql\MemberProfile', $sql, $params);
    }

    /**
     * @param $where string The WHERE clause
     * @param $params array The parameter values array
     * @return MemberProfileCollection
     * @throws \Exception
     */
    public function getMemberProfileCollectionByWhere($where, $params = array()) {
        return $this->getCollectionByWhere('Norm\mysql\MemberProfileCollection', $where, $params);
    }

    /**
     * @param $sql string The entire SQL clause
     * @param $params array The parameter values array
     * @return MemberProfileCollection
     * @throws \Exception
     */
    public function getMemberProfileCollectionBySql($sql, $params = array()) {
        return $this->getObjectBySql('Norm\mysql\MemberProfile', $sql, $params);
    }


    /**
     * @param $pks array|int|string|\DateTime The primary key/keys values
     * @return Location
     * @throws \Exception
     */
    public function getLocation($pks) {
        return $this->getObjectByPks('Norm\mysql\Location', $pks);
    }

    /**
     * @param $pks array An array of primary keys
     * @return LocationCollection
     * @throws \Exception
     */
    public function getLocationCollection($pks) {
        return $this->getCollectionByPks('Norm\mysql\LocationCollection', $pks);
    }

    /**
     * @param $where string The WHERE clause
     * @param $params array The parameter values array
     * @return Location
     * @throws \Exception
     */
    public function getLocationByWhere($where, $params = array()) {
        return $this->getObjectByWhere('Norm\mysql\Location', $where, $params);
    }

    /**
     * @param $sql string The entire SQL clause
     * @param $params array The parameter values array
     * @return Location
     * @throws \Exception
     */
    public function getLocationBySql($sql, $params = array()) {
        return $this->getObjectBySql('Norm\mysql\Location', $sql, $params);
    }

    /**
     * @param $where string The WHERE clause
     * @param $params array The parameter values array
     * @return LocationCollection
     * @throws \Exception
     */
    public function getLocationCollectionByWhere($where, $params = array()) {
        return $this->getCollectionByWhere('Norm\mysql\LocationCollection', $where, $params);
    }

    /**
     * @param $sql string The entire SQL clause
     * @param $params array The parameter values array
     * @return LocationCollection
     * @throws \Exception
     */
    public function getLocationCollectionBySql($sql, $params = array()) {
        return $this->getObjectBySql('Norm\mysql\Location', $sql, $params);
    }


}