<?php
namespace Norm\riak;

class MemberCompanyRating {

    /** @var string */
    public $memberId;

    /** @var string */
    public $companyId;

    /** @var int */
    public $rating;

    /** @var DateTime */
    public $createdAt;

    /** @var DateTime */
    public $updatedAt;


    public function __construct() {
    }
}

class MemberCompanyRatingCollection extends \ArrayObject {
}

class Service {
    const ENABLED_STATUS = 1;
    const DISABLED_STATUS = 2;


    /** @var string */
    public $id;

    /** @var int */
    public $mysqlId;

    /** @var string */
    public $companyId;

    /** @var string */
    public $name;

    /** @var string */
    public $description;

    /** @var float */
    public $discountedPrice;

    /** @var float */
    public $originalPrice;

    /** @var int */
    public $minsForService;

    /** @var int */
    public $minsNotice;

    /** @var int */
    public $status;

    /** @var DateTime */
    public $updatedAt;

    /** @var DateTime */
    public $createdAt;


    public function __construct() {
        $this->id = bin2hex(openssl_random_pseudo_bytes(16));
    }
}

class ServiceCollection extends \ArrayObject {
}

class ProviderAdFlag {
    const ENABLED_STATUS = 1;
    const DISABLED_STATUS = 2;


    /** @var string */
    public $id;

    /** @var string */
    public $authorId;

    /** @var string */
    public $companyId;

    /** @var string */
    public $locationId;

    /** @var string */
    public $adId;

    /** @var string */
    public $serviceId;

    /** @var string */
    public $body;

    /** @var int */
    public $status;

    /** @var DateTime */
    public $createdAt;


    public function __construct() {
        $this->id = bin2hex(openssl_random_pseudo_bytes(16));
    }
}

class ProviderAdFlagCollection extends \ArrayObject {
}

class Address {

    /** @var string */
    public $id;

    /** @var string */
    public $street1;

    /** @var string */
    public $street2;

    /** @var string */
    public $city;

    /** @var string */
    public $state;

    /** @var string */
    public $zip;

    /** @var string */
    public $phone;

    /** @var float */
    public $lat;

    /** @var float */
    public $long;


    public function __construct() {
        $this->id = bin2hex(openssl_random_pseudo_bytes(16));
    }
}

class AddressCollection extends \ArrayObject {
}

class CompanyReviews {

    /** @var string */
    public $companyId;

    /** @var string[] */
    public $reviewIds;

    /** @var DateTime */
    public $updatedAt;


    public function __construct() {
        $this->reviewIds = [];
    }
}

class CompanyReviewsCollection extends \ArrayObject {
}

class ProviderAd {
    const PUBLISHED_STATUS = 1;
    const UN_PUBISHED_STATUS = 2;
    const DELETED_STATUS = 3;


    /** @var string */
    public $id;

    /** @var string */
    public $locationId;

    /** @var string */
    public $companyId;

    /** @var string */
    public $calendarId;

    /** @var int */
    public $categoryId;

    /** @var string */
    public $currentImmutableId;

    /** @var string */
    public $title;

    /** @var string */
    public $description;

    /** @var int */
    public $adFlagTotal;

    /** @var string[] */
    public $photos;

    /** @var string[] */
    public $serviceIds;

    /** @var string[] */
    public $flagIds;

    /** @var int */
    public $status;

    /** @var DateTime */
    public $createdAt;

    /** @var DateTime */
    public $updatedAt;


    public function __construct() {
        $this->id = bin2hex(openssl_random_pseudo_bytes(16));
        $this->adFlagTotal = 0;
        $this->photos = [];
        $this->serviceIds = [];
        $this->flagIds = [];
    }
}

class ProviderAdCollection extends \ArrayObject {
}

class Calendar {
    const ENABLED_STATUS = 1;
    const DISABED_STATUS = 2;


    /** @var string */
    public $id;

    /** @var string */
    public $locationId;

    /** @var string */
    public $companyId;

    /** @var string */
    public $name;

    /** @var \Norm\riak\Availability[] */
    public $availabilities;

    /** @var \Norm\riak\Booking[] */
    public $bookings;

    /** @var int */
    public $status;

    /** @var DateTime */
    public $createdAt;

    /** @var DateTime */
    public $updatedAt;


    public function __construct() {
        $this->id = bin2hex(openssl_random_pseudo_bytes(16));
        $this->availabilities = [];
        $this->bookings = [];
    }
}

class CalendarCollection extends \ArrayObject {
}

class Session {

    /** @var string */
    public $id;

    /** @var string */
    public $userId;

    /** @var string */
    public $browserHash;

    /** @var array */
    public $sessionBag;

    /** @var DateTime */
    public $createdAt;


    public function __construct() {
        $this->id = bin2hex(openssl_random_pseudo_bytes(16));
    }
}

class SessionCollection extends \ArrayObject {
}

class Message {
    const UNREAD_STATUS = 1;
    const READ_STATUS = 2;
    const DELETED_STATUS = 3;


    /** @var string */
    public $id;

    /** @var string */
    public $adId;

    /** @var string */
    public $authorKey;

    /** @var string */
    public $body;

    /** @var int */
    public $status;

    /** @var MessageFlag[] */
    public $flags;

    /** @var DateTime */
    public $createdAt;


    public function __construct() {
        $this->flags = [];
    }
}

class MessageCollection extends \ArrayObject {
}

class MessageFlag {

    /** @var string */
    public $messageKey;

    /** @var string */
    public $authorKey;

    /** @var string */
    public $body;

    /** @var int */
    public $status;

    /** @var DateTime */
    public $createdAt;


    public function __construct() {
    }
}

class MessageFlagCollection extends \ArrayObject {
}

class ReviewFlag {
    const ENABLED_STATUS = 1;
    const DISABLED_STATUS = 2;


    /** @var string */
    public $id;

    /** @var string */
    public $authorId;

    /** @var string */
    public $body;

    /** @var int */
    public $status;

    /** @var DateTime */
    public $createdAt;


    public function __construct() {
        $this->id = bin2hex(openssl_random_pseudo_bytes(16));
    }
}

class ReviewFlagCollection extends \ArrayObject {
}

class Booking {
    const SHORT_BOOKING_TYPE = 1;
    const SYSTEM_BOOKING_TYPE = 2;


    /** @var string */
    public $id;

    /** @var string */
    public $title;

    /** @var string */
    public $bookingDetailId;

    /** @var int */
    public $type;

    /** @var DateTime */
    public $start;

    /** @var DateTime */
    public $end;


    public function __construct() {
        $this->id = bin2hex(openssl_random_pseudo_bytes(16));
    }
}

class BookingCollection extends \ArrayObject {
}

class Review {
    const ENABLED_STATUS = 1;
    const DISABLED_STATUS = 2;


    /** @var string */
    public $id;

    /** @var string */
    public $authorId;

    /** @var string */
    public $companyId;

    /** @var string */
    public $locationId;

    /** @var string */
    public $adId;

    /** @var string */
    public $serviceId;

    /** @var string */
    public $authorScreenname;

    /** @var string */
    public $body;

    /** @var int */
    public $rating;

    /** @var \Norm\riak\ReviewFlagCollection */
    public $flags;

    /** @var int */
    public $status;

    /** @var DateTime */
    public $createdAt;


    public function __construct() {
        $this->id = bin2hex(openssl_random_pseudo_bytes(16));
        $this->flags = new \Norm\riak\ReviewFlagCollection();
    }
}

class ReviewCollection extends \ArrayObject {
}

class BookingDetail {
    const PAY_PAL_PAYMENT__TYPE = 1;
    const CREDIT_CARD_PAYMENT__TYPE = 2;

    const PENDING_STATUS = 1;
    const COMPLETED_STATUS = 2;
    const CANCELED_STATUS = 3;


    /** @var string */
    public $id;

    /** @var string */
    public $locationId;

    /** @var string */
    public $companyId;

    /** @var string */
    public $calendarId;

    /** @var string */
    public $serviceId;

    /** @var string */
    public $adId;

    /** @var string */
    public $memberId;

    /** @var DateTime */
    public $start;

    /** @var DateTime */
    public $end;

    /** @var int */
    public $paymentType;

    /** @var string */
    public $paymentId;

    /** @var string */
    public $cancellationPolicy;

    /** @var int */
    public $status;

    /** @var DateTime */
    public $createdAt;

    /** @var DateTime */
    public $updatedAt;


    public function __construct() {
        $this->id = bin2hex(openssl_random_pseudo_bytes(16));
    }
}

class BookingDetailCollection extends \ArrayObject {
}

class CompanyPhotos {

    /** @var string */
    public $companyId;

    /** @var string[] */
    public $photos;


    public function __construct() {
        $this->photos = [];
    }
}

class CompanyPhotosCollection extends \ArrayObject {
}

class Member {
    const ACTIVE_STATUS = 1;
    const DELETED_STATUS = 2;
    const LOCKED_STATUS = 3;
    const BANNED_STATUS = 4;
    const PARTIAL_REGISTRATION_STATUS = 5;

    const USER_ROLE = 1;
    const SUPPORT_ROLE = 2;
    const ADMIN_ROLE = 3;
    const SUPER_ADMIN_ROLE = 4;


    /** @var string */
    public $id;

    /** @var int */
    public $mysqlId;

    /** @var string */
    public $email;

    /** @var string */
    public $password;

    /** @var string */
    public $passwordResetCode;

    /** @var string */
    public $name;

    /** @var string */
    public $mobile;

    /** @var Date */
    public $dob;

    /** @var string */
    public $photo;

    /** @var int */
    public $status;

    /** @var int */
    public $role;

    /** @var Date */
    public $lastActivityDate;

    /** @var string[] */
    public $blockedCompanyIds;

    /** @var string[] */
    public $managedCompanyIds;

    /** @var string[] */
    public $adFlagKeys;

    /** @var string[] */
    public $messageFlagKeys;

    /** @var DateTime */
    public $createdAt;

    /** @var DateTime */
    public $updatedAt;


    public function __construct() {
        $this->id = bin2hex(openssl_random_pseudo_bytes(16));
        $this->lastActivityDate = new \DateTime();
        $this->blockedCompanyIds = [];
        $this->managedCompanyIds = [];
        $this->adFlagKeys = [];
        $this->messageFlagKeys = [];
    }
}

class MemberCollection extends \ArrayObject {
}

class Company {
    const BASIC_PLAN = 1;
    const PREMIUM_PLAN = 2;

    const ENABLED_STATUS = 1;
    const DISABLED_STATUS = 2;


    /** @var string */
    public $id;

    /** @var int */
    public $mysqlId;

    /** @var string */
    public $name;

    /** @var string */
    public $description;

    /** @var int */
    public $plan;

    /** @var int */
    public $ratingCount;

    /** @var int */
    public $ratingTotal;

    /** @var float */
    public $ratingAvg;

    /** @var string[] */
    public $administerMemberIds;

    /** @var string[] */
    public $locationIds;

    /** @var string[] */
    public $flagIds;

    /** @var int */
    public $status;

    /** @var DateTime */
    public $createdAt;

    /** @var DateTime */
    public $updatedAt;


    public function __construct() {
        $this->id = bin2hex(openssl_random_pseudo_bytes(16));
        $this->administerMemberIds = [];
        $this->locationIds = [];
        $this->flagIds = [];
    }
}

class CompanyCollection extends \ArrayObject {
}

class CompanyServices {

    /** @var string */
    public $companyId;

    /** @var \Norm\riak\ServiceCollection */
    public $services;

    /** @var DateTime */
    public $updatedAt;


    public function __construct() {
        $this->services = new \Norm\riak\ServiceCollection();
    }
}

class CompanyServicesCollection extends \ArrayObject {
}

class Availability {

    /** @var string */
    public $id;

    /** @var DateTime */
    public $start;

    /** @var DateTime */
    public $end;


    public function __construct() {
        $this->id = bin2hex(openssl_random_pseudo_bytes(16));
    }
}

class AvailabilityCollection extends \ArrayObject {
}

class Zipcode {

    /** @var int */
    public $id;

    /** @var string */
    public $city;

    /** @var string */
    public $state;

    /** @var int */
    public $dstTimezoneOffset;

    /** @var int */
    public $rawTimezoneOffset;

    /** @var string */
    public $timezoneId;

    /** @var string */
    public $timezoneName;

    /** @var float */
    public $lat;

    /** @var float */
    public $long;

    /** @var float */
    public $northLat;

    /** @var float */
    public $southLat;

    /** @var float */
    public $eastLong;

    /** @var float */
    public $westLong;

    /** @var DateTime */
    public $createdAt;


    public function __construct() {
    }
}

class ZipcodeCollection extends \ArrayObject {
}

class MemberProfile {

    /** @var string */
    public $id;

    /** @var int */
    public $mysqlId;

    /** @var string */
    public $fbId;

    /** @var string */
    public $fbAccessToken;

    /** @var string */
    public $fname;

    /** @var string */
    public $lname;

    /** @var string */
    public $gender;

    /** @var string */
    public $locale;

    /** @var int */
    public $timezone;

    /** @var DateTime */
    public $createdAt;

    /** @var DateTime */
    public $updatedAt;


    public function __construct() {
    }
}

class MemberProfileCollection extends \ArrayObject {
}

class ProviderAdImmutable {

    /** @var string */
    public $id;

    /** @var \Norm\riak\ProviderAd */
    public $providerAd;

    /** @var \Norm\riak\Location */
    public $location;

    /** @var \Norm\riak\Company */
    public $company;

    /** @var \Norm\riak\Calendar */
    public $calendar;

    /** @var \Norm\riak\Service[] */
    public $services;

    /** @var DateTime */
    public $createdAt;


    public function __construct() {
        $this->id = bin2hex(openssl_random_pseudo_bytes(16));
        $this->services = [];
    }
}

class ProviderAdImmutableCollection extends \ArrayObject {
}

class Location {
    const ENABLED_STATUS = 1;
    const DISABLED_STATUS = 2;


    /** @var string */
    public $id;

    /** @var int */
    public $mysqlId;

    /** @var string */
    public $companyId;

    /** @var string[] */
    public $calendarIds;

    /** @var string */
    public $name;

    /** @var \Norm\riak\Address */
    public $address;

    /** @var bool */
    public $isMobile;

    /** @var int */
    public $status;

    /** @var DateTime */
    public $createdAt;

    /** @var DateTime */
    public $updatedAt;


    public function __construct() {
        $this->id = bin2hex(openssl_random_pseudo_bytes(16));
        $this->calendarIds = [];
    }
}

class LocationCollection extends \ArrayObject {
}

class CompanyAds {

    /** @var string */
    public $companyId;

    /** @var string[] */
    public $publishedAdIds;

    /** @var string[] */
    public $unpublishedAdIds;

    /** @var string[] */
    public $deletedAdIds;


    public function __construct() {
        $this->publishedAdIds = [];
        $this->unpublishedAdIds = [];
        $this->deletedAdIds = [];
    }
}

class CompanyAdsCollection extends \ArrayObject {
}

