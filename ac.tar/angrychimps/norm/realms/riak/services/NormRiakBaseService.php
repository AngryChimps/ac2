<?php

namespace AC\NormBundle\cached\realms\riak\services;

use AC\NormBundle\Services\NormService;
use AC\NormBundle\Services\DatastoreService;
use AC\NormBundle\Services\traits\RiakBlobTrait;
use AC\NormBundle\Services\traits\RiakTrait;

use Norm\riak\MemberCompanyRating;
use Norm\riak\Service;
use Norm\riak\ProviderAdFlag;
use Norm\riak\Address;
use Norm\riak\CompanyReviews;
use Norm\riak\ProviderAd;
use Norm\riak\Calendar;
use Norm\riak\Session;
use Norm\riak\Message;
use Norm\riak\MessageFlag;
use Norm\riak\ReviewFlag;
use Norm\riak\Booking;
use Norm\riak\Review;
use Norm\riak\BookingDetail;
use Norm\riak\CompanyPhotos;
use Norm\riak\Member;
use Norm\riak\Company;
use Norm\riak\CompanyServices;
use Norm\riak\Availability;
use Norm\riak\Zipcode;
use Norm\riak\MemberProfile;
use Norm\riak\ProviderAdImmutable;
use Norm\riak\Location;
use Norm\riak\CompanyAds;

class NormRiakBaseService extends NormService {
    use RiakBlobTrait;
    use RiakTrait;

    /**
     * @param $pks array|int|string|\DateTime The primary key/keys values
     * @return MemberCompanyRating
     * @throws \Exception
     */
    public function getMemberCompanyRating($pks) {
        return $this->getObjectByPks('Norm\riak\MemberCompanyRating', $pks);
    }

    /**
     * @param $pks array An array of primary keys
     * @return MemberCompanyRatingCollection
     * @throws \Exception
     */
    public function getMemberCompanyRatingCollection($pks) {
        return $this->getCollectionByPks('Norm\riak\MemberCompanyRatingCollection', $pks);
    }


    /**
     * @param $pks array|int|string|\DateTime The primary key/keys values
     * @return Service
     * @throws \Exception
     */
    public function getService($pks) {
        return $this->getObjectByPks('Norm\riak\Service', $pks);
    }

    /**
     * @param $pks array An array of primary keys
     * @return ServiceCollection
     * @throws \Exception
     */
    public function getServiceCollection($pks) {
        return $this->getCollectionByPks('Norm\riak\ServiceCollection', $pks);
    }


    /**
     * @param $pks array|int|string|\DateTime The primary key/keys values
     * @return ProviderAdFlag
     * @throws \Exception
     */
    public function getProviderAdFlag($pks) {
        return $this->getObjectByPks('Norm\riak\ProviderAdFlag', $pks);
    }

    /**
     * @param $pks array An array of primary keys
     * @return ProviderAdFlagCollection
     * @throws \Exception
     */
    public function getProviderAdFlagCollection($pks) {
        return $this->getCollectionByPks('Norm\riak\ProviderAdFlagCollection', $pks);
    }


    /**
     * @param $pks array|int|string|\DateTime The primary key/keys values
     * @return Address
     * @throws \Exception
     */
    public function getAddress($pks) {
        return $this->getObjectByPks('Norm\riak\Address', $pks);
    }

    /**
     * @param $pks array An array of primary keys
     * @return AddressCollection
     * @throws \Exception
     */
    public function getAddressCollection($pks) {
        return $this->getCollectionByPks('Norm\riak\AddressCollection', $pks);
    }


    /**
     * @param $pks array|int|string|\DateTime The primary key/keys values
     * @return CompanyReviews
     * @throws \Exception
     */
    public function getCompanyReviews($pks) {
        return $this->getObjectByPks('Norm\riak\CompanyReviews', $pks);
    }

    /**
     * @param $pks array An array of primary keys
     * @return CompanyReviewsCollection
     * @throws \Exception
     */
    public function getCompanyReviewsCollection($pks) {
        return $this->getCollectionByPks('Norm\riak\CompanyReviewsCollection', $pks);
    }


    /**
     * @param $pks array|int|string|\DateTime The primary key/keys values
     * @return ProviderAd
     * @throws \Exception
     */
    public function getProviderAd($pks) {
        return $this->getObjectByPks('Norm\riak\ProviderAd', $pks);
    }

    /**
     * @param $pks array An array of primary keys
     * @return ProviderAdCollection
     * @throws \Exception
     */
    public function getProviderAdCollection($pks) {
        return $this->getCollectionByPks('Norm\riak\ProviderAdCollection', $pks);
    }


    /**
     * @param $pks array|int|string|\DateTime The primary key/keys values
     * @return Calendar
     * @throws \Exception
     */
    public function getCalendar($pks) {
        return $this->getObjectByPks('Norm\riak\Calendar', $pks);
    }

    /**
     * @param $pks array An array of primary keys
     * @return CalendarCollection
     * @throws \Exception
     */
    public function getCalendarCollection($pks) {
        return $this->getCollectionByPks('Norm\riak\CalendarCollection', $pks);
    }


    /**
     * @param $pks array|int|string|\DateTime The primary key/keys values
     * @return Session
     * @throws \Exception
     */
    public function getSession($pks) {
        return $this->getObjectByPks('Norm\riak\Session', $pks);
    }

    /**
     * @param $pks array An array of primary keys
     * @return SessionCollection
     * @throws \Exception
     */
    public function getSessionCollection($pks) {
        return $this->getCollectionByPks('Norm\riak\SessionCollection', $pks);
    }


    /**
     * @param $pks array|int|string|\DateTime The primary key/keys values
     * @return Message
     * @throws \Exception
     */
    public function getMessage($pks) {
        return $this->getObjectByPks('Norm\riak\Message', $pks);
    }

    /**
     * @param $pks array An array of primary keys
     * @return MessageCollection
     * @throws \Exception
     */
    public function getMessageCollection($pks) {
        return $this->getCollectionByPks('Norm\riak\MessageCollection', $pks);
    }


    /**
     * @param $pks array|int|string|\DateTime The primary key/keys values
     * @return MessageFlag
     * @throws \Exception
     */
    public function getMessageFlag($pks) {
        return $this->getObjectByPks('Norm\riak\MessageFlag', $pks);
    }

    /**
     * @param $pks array An array of primary keys
     * @return MessageFlagCollection
     * @throws \Exception
     */
    public function getMessageFlagCollection($pks) {
        return $this->getCollectionByPks('Norm\riak\MessageFlagCollection', $pks);
    }


    /**
     * @param $pks array|int|string|\DateTime The primary key/keys values
     * @return ReviewFlag
     * @throws \Exception
     */
    public function getReviewFlag($pks) {
        return $this->getObjectByPks('Norm\riak\ReviewFlag', $pks);
    }

    /**
     * @param $pks array An array of primary keys
     * @return ReviewFlagCollection
     * @throws \Exception
     */
    public function getReviewFlagCollection($pks) {
        return $this->getCollectionByPks('Norm\riak\ReviewFlagCollection', $pks);
    }


    /**
     * @param $pks array|int|string|\DateTime The primary key/keys values
     * @return Booking
     * @throws \Exception
     */
    public function getBooking($pks) {
        return $this->getObjectByPks('Norm\riak\Booking', $pks);
    }

    /**
     * @param $pks array An array of primary keys
     * @return BookingCollection
     * @throws \Exception
     */
    public function getBookingCollection($pks) {
        return $this->getCollectionByPks('Norm\riak\BookingCollection', $pks);
    }


    /**
     * @param $pks array|int|string|\DateTime The primary key/keys values
     * @return Review
     * @throws \Exception
     */
    public function getReview($pks) {
        return $this->getObjectByPks('Norm\riak\Review', $pks);
    }

    /**
     * @param $pks array An array of primary keys
     * @return ReviewCollection
     * @throws \Exception
     */
    public function getReviewCollection($pks) {
        return $this->getCollectionByPks('Norm\riak\ReviewCollection', $pks);
    }


    /**
     * @param $pks array|int|string|\DateTime The primary key/keys values
     * @return BookingDetail
     * @throws \Exception
     */
    public function getBookingDetail($pks) {
        return $this->getObjectByPks('Norm\riak\BookingDetail', $pks);
    }

    /**
     * @param $pks array An array of primary keys
     * @return BookingDetailCollection
     * @throws \Exception
     */
    public function getBookingDetailCollection($pks) {
        return $this->getCollectionByPks('Norm\riak\BookingDetailCollection', $pks);
    }


    /**
     * @param $pks array|int|string|\DateTime The primary key/keys values
     * @return CompanyPhotos
     * @throws \Exception
     */
    public function getCompanyPhotos($pks) {
        return $this->getObjectByPks('Norm\riak\CompanyPhotos', $pks);
    }

    /**
     * @param $pks array An array of primary keys
     * @return CompanyPhotosCollection
     * @throws \Exception
     */
    public function getCompanyPhotosCollection($pks) {
        return $this->getCollectionByPks('Norm\riak\CompanyPhotosCollection', $pks);
    }


    /**
     * @param $pks array|int|string|\DateTime The primary key/keys values
     * @return Member
     * @throws \Exception
     */
    public function getMember($pks) {
        return $this->getObjectByPks('Norm\riak\Member', $pks);
    }

    /**
     * @param $pks array An array of primary keys
     * @return MemberCollection
     * @throws \Exception
     */
    public function getMemberCollection($pks) {
        return $this->getCollectionByPks('Norm\riak\MemberCollection', $pks);
    }


    /**
     * @param $pks array|int|string|\DateTime The primary key/keys values
     * @return Company
     * @throws \Exception
     */
    public function getCompany($pks) {
        return $this->getObjectByPks('Norm\riak\Company', $pks);
    }

    /**
     * @param $pks array An array of primary keys
     * @return CompanyCollection
     * @throws \Exception
     */
    public function getCompanyCollection($pks) {
        return $this->getCollectionByPks('Norm\riak\CompanyCollection', $pks);
    }


    /**
     * @param $pks array|int|string|\DateTime The primary key/keys values
     * @return CompanyServices
     * @throws \Exception
     */
    public function getCompanyServices($pks) {
        return $this->getObjectByPks('Norm\riak\CompanyServices', $pks);
    }

    /**
     * @param $pks array An array of primary keys
     * @return CompanyServicesCollection
     * @throws \Exception
     */
    public function getCompanyServicesCollection($pks) {
        return $this->getCollectionByPks('Norm\riak\CompanyServicesCollection', $pks);
    }


    /**
     * @param $pks array|int|string|\DateTime The primary key/keys values
     * @return Availability
     * @throws \Exception
     */
    public function getAvailability($pks) {
        return $this->getObjectByPks('Norm\riak\Availability', $pks);
    }

    /**
     * @param $pks array An array of primary keys
     * @return AvailabilityCollection
     * @throws \Exception
     */
    public function getAvailabilityCollection($pks) {
        return $this->getCollectionByPks('Norm\riak\AvailabilityCollection', $pks);
    }


    /**
     * @param $pks array|int|string|\DateTime The primary key/keys values
     * @return Zipcode
     * @throws \Exception
     */
    public function getZipcode($pks) {
        return $this->getObjectByPks('Norm\riak\Zipcode', $pks);
    }

    /**
     * @param $pks array An array of primary keys
     * @return ZipcodeCollection
     * @throws \Exception
     */
    public function getZipcodeCollection($pks) {
        return $this->getCollectionByPks('Norm\riak\ZipcodeCollection', $pks);
    }


    /**
     * @param $pks array|int|string|\DateTime The primary key/keys values
     * @return MemberProfile
     * @throws \Exception
     */
    public function getMemberProfile($pks) {
        return $this->getObjectByPks('Norm\riak\MemberProfile', $pks);
    }

    /**
     * @param $pks array An array of primary keys
     * @return MemberProfileCollection
     * @throws \Exception
     */
    public function getMemberProfileCollection($pks) {
        return $this->getCollectionByPks('Norm\riak\MemberProfileCollection', $pks);
    }


    /**
     * @param $pks array|int|string|\DateTime The primary key/keys values
     * @return ProviderAdImmutable
     * @throws \Exception
     */
    public function getProviderAdImmutable($pks) {
        return $this->getObjectByPks('Norm\riak\ProviderAdImmutable', $pks);
    }

    /**
     * @param $pks array An array of primary keys
     * @return ProviderAdImmutableCollection
     * @throws \Exception
     */
    public function getProviderAdImmutableCollection($pks) {
        return $this->getCollectionByPks('Norm\riak\ProviderAdImmutableCollection', $pks);
    }


    /**
     * @param $pks array|int|string|\DateTime The primary key/keys values
     * @return Location
     * @throws \Exception
     */
    public function getLocation($pks) {
        return $this->getObjectByPks('Norm\riak\Location', $pks);
    }

    /**
     * @param $pks array An array of primary keys
     * @return LocationCollection
     * @throws \Exception
     */
    public function getLocationCollection($pks) {
        return $this->getCollectionByPks('Norm\riak\LocationCollection', $pks);
    }


    /**
     * @param $pks array|int|string|\DateTime The primary key/keys values
     * @return CompanyAds
     * @throws \Exception
     */
    public function getCompanyAds($pks) {
        return $this->getObjectByPks('Norm\riak\CompanyAds', $pks);
    }

    /**
     * @param $pks array An array of primary keys
     * @return CompanyAdsCollection
     * @throws \Exception
     */
    public function getCompanyAdsCollection($pks) {
        return $this->getCollectionByPks('Norm\riak\CompanyAdsCollection', $pks);
    }


}