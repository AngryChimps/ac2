<?php

namespace AC\NormBundle\cached\realms\es\services;

use AC\NormBundle\Services\NormService;
use AC\NormBundle\Services\DatastoreService;
use AC\NormBundle\Services\traits\ElasticsearchTrait;

use Norm\es\ProviderAdListing;

class NormEsBaseService extends NormService {
    use ElasticsearchTrait;

    /**
     * @param $pks array|int|string|\DateTime The primary key/keys values
     * @return ProviderAdListing
     * @throws \Exception
     */
    public function getProviderAdListing($pks) {
        return $this->getObjectByPks('Norm\es\ProviderAdListing', $pks);
    }

    /**
     * @param $pks array An array of primary keys
     * @return ProviderAdListingCollection
     * @throws \Exception
     */
    public function getProviderAdListingCollection($pks) {
        return $this->getCollectionByPks('Norm\es\ProviderAdListingCollection', $pks);
    }


}