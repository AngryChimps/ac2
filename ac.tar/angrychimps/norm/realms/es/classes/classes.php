<?php
namespace Norm\es;

class ProviderAdListing {

    /** @var string */
    public $providerAdImmutableId;

    /** @var string */
    public $providerAdId;

    /** @var string */
    public $companyName;

    /** @var string */
    public $title;

    /** @var string */
    public $photo;

    /** @var \Norm\riak\Address */
    public $address;

    /** @var float */
    public $rating;

    /** @var \Norm\riak\AvailabilityCollection */
    public $availabilities;

    /** @var DateTime */
    public $updatedAt;


    public function __construct() {
        $this->availabilities = new \Norm\riak\AvailabilityCollection();
    }
}

class ProviderAdListingCollection extends \ArrayObject {
}

